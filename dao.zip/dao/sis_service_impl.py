from dao.sis_service import ISisService
from util.db_conn_util import DBConnUtil

class SisServiceImpl(ISisService):

    def __init__(self):
        self.conn = DBConnUtil.get_connection()

    def _fetch_query(self, query, params=None):
        with self.conn.cursor() as cursor:
            cursor.execute(query, params or ())
            return cursor.fetchall()

    def get_total_payments_per_student(self):
        query = """
            SELECT s.student_id, s.first_name, s.last_name, SUM(p.amount) AS total_paid
            FROM Students s
            JOIN Payments p ON s.student_id = p.student_id
            GROUP BY s.student_id;
        """
        return self._fetch_query(query)

    def get_students_without_enrollments(self):
        query = """
            SELECT s.student_id, s.first_name, s.last_name
            FROM Students s
            LEFT JOIN Enrollments e ON s.student_id = e.student_id
            WHERE e.enrollment_id IS NULL;
        """
        return self._fetch_query(query)

    def get_enrollment_count_per_course(self):
        query = """
            SELECT c.course_id, c.course_name, COUNT(e.enrollment_id) AS enrolled_count
            FROM Courses c
            LEFT JOIN Enrollments e ON c.course_id = e.course_id
            GROUP BY c.course_id;
        """
        return self._fetch_query(query)

    def get_total_payments_per_course(self):
        query = """
            SELECT c.course_id, c.course_name, SUM(p.amount) AS total_payment
            FROM Courses c
            JOIN Enrollments e ON c.course_id = e.course_id
            JOIN Payments p ON e.student_id = p.student_id
            GROUP BY c.course_id;
        """
        return self._fetch_query(query)

    def get_students_paid_more_than_500(self):
        query = """
            SELECT s.student_id, s.first_name, s.last_name, p.amount
            FROM Students s
            JOIN Payments p ON s.student_id = p.student_id
            WHERE p.amount > 500;
        """
        return self._fetch_query(query)

    def get_courses_with_more_than_three_enrollments(self):
        query = """
            SELECT c.course_id, c.course_name, COUNT(e.student_id) AS total_enrolled
            FROM Courses c
            JOIN Enrollments e ON c.course_id = e.course_id
            GROUP BY c.course_id
            HAVING total_enrolled > 3;
        """
        return self._fetch_query(query)

    def get_teacher_course_count(self):
        query = """
            SELECT t.teacher_id, t.first_name, t.last_name, COUNT(c.course_id) AS course_count
            FROM Teachers t
            LEFT JOIN Courses c ON t.teacher_id = c.teacher_id
            GROUP BY t.teacher_id;
        """
        return self._fetch_query(query)

    def get_students_in_machine_learning(self):
        query = """
            SELECT s.student_id, s.first_name, s.last_name
            FROM Students s
            JOIN Enrollments e ON s.student_id = e.student_id
            JOIN Courses c ON e.course_id = c.course_id
            WHERE c.course_name = 'Machine Learning';
        """
        return self._fetch_query(query)

    def get_average_payment_amount(self):
        query = "SELECT AVG(amount) AS average_payment FROM Payments;"
        return self._fetch_query(query)

    def get_students_starting_with_a(self):
        query = "SELECT * FROM Students WHERE first_name LIKE 'A%';"
        return self._fetch_query(query)

    def get_students_ordered_by_total_payment(self):
        query = """
            SELECT s.student_id, s.first_name, s.last_name, SUM(p.amount) AS total_payment
            FROM Students s
            JOIN Payments p ON s.student_id = p.student_id
            GROUP BY s.student_id
            ORDER BY total_payment DESC;
        """
        return self._fetch_query(query)

    def get_summary_counts(self):
        query = """
            SELECT
                (SELECT COUNT(*) FROM Students) AS total_students,
                (SELECT COUNT(*) FROM Teachers) AS total_teachers,
                (SELECT COUNT(*) FROM Courses) AS total_courses;
        """
        return self._fetch_query(query)

    def get_students_enrolled_after(self, date):
        query = """
            SELECT s.student_id, s.first_name, s.last_name, e.enrollment_date
            FROM Students s
            JOIN Enrollments e ON s.student_id = e.student_id
            WHERE e.enrollment_date > %s;
        """
        return self._fetch_query(query, (date,))

    def get_courses_with_no_enrollments(self):
        query = """
            SELECT c.course_id, c.course_name
            FROM Courses c
            LEFT JOIN Enrollments e ON c.course_id = e.course_id
            WHERE e.course_id IS NULL;
        """
        return self._fetch_query(query)

    def get_teachers_with_no_courses(self):
        query = """
            SELECT t.teacher_id, t.first_name, t.last_name
            FROM Teachers t
            LEFT JOIN Courses c ON t.teacher_id = c.teacher_id
            WHERE c.teacher_id IS NULL;
        """
        return self._fetch_query(query)

    def get_payment_summary_per_student(self):
        query = """
            SELECT student_id, COUNT(*) AS total_transactions, SUM(amount) AS total_amount
            FROM Payments
            GROUP BY student_id;
        """
        return self._fetch_query(query)

    def get_students_in_multiple_courses(self):
        query = """
            SELECT student_id, COUNT(course_id) AS course_count
            FROM Enrollments
            GROUP BY student_id
            HAVING course_count > 1;
        """
        return self._fetch_query(query)

    def get_payment_status_per_student(self):
        query = """
            SELECT s.student_id, s.first_name, s.last_name,
                   CASE WHEN p.payment_id IS NULL THEN 'Not Paid' ELSE 'Paid' END AS payment_status
            FROM Students s
            LEFT JOIN Payments p ON s.student_id = p.student_id;
        """
        return self._fetch_query(query)

    def get_top_enrolled_courses(self, top_n=3):
        query = f"""
            SELECT course_id, COUNT(enrollment_id) AS total_enrollments
            FROM Enrollments
            GROUP BY course_id
            ORDER BY total_enrollments DESC
            LIMIT {top_n};
        """
        return self._fetch_query(query)

    def get_total_revenue(self):
        query = "SELECT SUM(amount) AS total_revenue FROM Payments;"
        return self._fetch_query(query)
