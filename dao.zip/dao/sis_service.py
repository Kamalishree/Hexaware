from abc import ABC, abstractmethod

class ISisService(ABC):

    @abstractmethod
    def get_total_payments_per_student(self):
        pass

    @abstractmethod
    def get_students_without_enrollments(self):
        pass

    @abstractmethod
    def get_enrollment_count_per_course(self):
        pass

    @abstractmethod
    def get_total_payments_per_course(self):
        pass

    @abstractmethod
    def get_students_paid_more_than_500(self):
        pass

    @abstractmethod
    def get_courses_with_more_than_three_enrollments(self):
        pass

    @abstractmethod
    def get_teacher_course_count(self):
        pass

    @abstractmethod
    def get_students_in_machine_learning(self):
        pass

    @abstractmethod
    def get_average_payment_amount(self):
        pass

    @abstractmethod
    def get_students_starting_with_a(self):
        pass

    @abstractmethod
    def get_students_ordered_by_total_payment(self):
        pass

    @abstractmethod
    def get_summary_counts(self):
        pass

    @abstractmethod
    def get_students_enrolled_after(self, date):
        pass

    @abstractmethod
    def get_courses_with_no_enrollments(self):
        pass

    @abstractmethod
    def get_teachers_with_no_courses(self):
        pass

    @abstractmethod
    def get_payment_summary_per_student(self):
        pass

    @abstractmethod
    def get_students_in_multiple_courses(self):
        pass

    @abstractmethod
    def get_payment_status_per_student(self):
        pass

    @abstractmethod
    def get_top_enrolled_courses(self, top_n=3):
        pass

    @abstractmethod
    def get_total_revenue(self):
        pass
